import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.HashMap;

public class MapOfHashmatiqueTest {
    public static void main(String[] args){
        MapOfHashmatique id = new MapOfHashmatique();

        HashMap<String, String> results = id.getLyrics();
    }
}